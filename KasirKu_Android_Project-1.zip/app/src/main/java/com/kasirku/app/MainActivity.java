package com.kasirku.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){ super.onCreate(b); web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(this,"Android");
    web.loadUrl("file:///android_asset/index.html");
  }
  @JavascriptInterface public void shareWhatsApp(String text){
    runOnUiThread(()->{ try { Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text="+Uri.encode(text))); startActivity(i); } catch(Exception e){} });
  }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
